package kr.ac.kumoh.s20150088.imagepdf

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.Volley
import com.pspdfkit.document.PdfDocument
import com.pspdfkit.document.PdfDocumentLoader
import com.pspdfkit.utils.Size
import kotlinx.android.synthetic.main.activity_show_pdf.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.HashMap


class showPdfActivity : AppCompatActivity() {
    companion object{
        private val OPEN_DOCUMENT_REQUEST_CODE = 0x33
        lateinit var documentUri : Uri
        lateinit var document : PdfDocument
        var pageIndex = 0
        //서버 통신
        private val SERVER_URL: String = "http://bustercallapi.r-e.kr/"
        lateinit var mQueue: RequestQueue
        var mResult: JSONObject? = null
    }

    private var imageData: ByteArray? = null

    lateinit var myView:MyView

    var view_height : Int = 0
    var view_width : Int = 0
    var rotatedBitmap: Bitmap? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_pdf)
        launchSystemFilePicker()
        myView = MyView(this)
        previousButton.setOnClickListener {
            if(pageIndex > 0) {
                pageIndex -= 1
                showPdf()
            }
            else
            {
                pageIndex = 0
                showPdf()
            }
        }
        nextButton.setOnClickListener {
            if (pageIndex < document.pageCount-1) {
                pageIndex += 1
                showPdf()
            }
            else {
                pageIndex = document.pageCount-1
                showPdf()
            }
        }
        btnSend.setOnClickListener {
            uploadImage()
        }
    }


    private fun launchSystemFilePicker() {
        val openIntent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        openIntent.addCategory(Intent.CATEGORY_OPENABLE)
        openIntent.type = "application/*"
        startActivityForResult(openIntent, OPEN_DOCUMENT_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OPEN_DOCUMENT_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            val uri = data.data
            //documentUri = Uri.parse(uri.toString())
            if(uri != null) {
                //prepareAndShowDocument(uri);
                document = PdfDocumentLoader.openDocument(this, uri)
                showPdf()
            }
        }

    }


    private fun showPdf() {
        // Page size is in PDF points (not pixels).
        val pageSize : Size = document.getPageSize(pageIndex)
        // We define a target width for the resulting bitmap and use it to calculate the final height.
        val width = 1024
        val height = (pageSize.height * (width / pageSize.width)).toInt()

        // This will render the first page uniformly into a bitmap with a width of 2,048 pixels.
        val pageBitmap : Bitmap = document.renderPageToBitmap(this, pageIndex, width, height)
        //이미지 전송을 위한 bitmap 바이트 배열 변환
        imageData = bitmapToByteArray(pageBitmap)
        rotatedBitmap = pageBitmap
        MyView.bmp = pageBitmap
        my_view_pdf.invalidate()
    }

    fun bitmapToByteArray(bitmap: Bitmap) : ByteArray{
        var stream: ByteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
        var byteArray:ByteArray = stream.toByteArray()
        return byteArray
    }

    private fun uploadImage(){
        imageData?: return
        val url = SERVER_URL+"getImage"
        val request = object : VolleyFileUploadRequest(
            Request.Method.POST,
            url,
            Response.Listener {
                mResult = JSONObject(String(it.data))
                Log.i("response",mResult.toString())
            },
            Response.ErrorListener {
                println("오류 : $it")
            }

        ) {
            override fun getByteData(): MutableMap<String, FileDataPart> {
                var params = HashMap<String, FileDataPart>()
                params["image"] = FileDataPart("pdfTest_resized.jpg", imageData!!, "jpg")
                return params
            }
        }
        mQueue = Volley.newRequestQueue(this)
        mQueue.add(request)
    }
//    override fun onWindowFocusChanged(hasFocus: Boolean) {
//        view_height = my_view_pdf.height
//        view_width = my_view_pdf.width
//        var rotate_height = rotatedBitmap!!.height
//        var ratio_h = view_height.toFloat() / rotate_height.toFloat()
//        var widthTest = rotatedBitmap!!.width * ratio_h
//
//        var rotate_width = rotatedBitmap!!.width
//        var ratio_w = view_width.toFloat() / rotate_width.toFloat()
//        var heightTest = rotatedBitmap!!.height*ratio_w
//        var resized:Bitmap
//        if(heightTest.toInt() > view_height){
//            resized = Bitmap.createScaledBitmap(rotatedBitmap!!, widthTest.toInt(), view_height, false)
//        }
//        else{
//            resized = Bitmap.createScaledBitmap(rotatedBitmap!!, view_width, heightTest.toInt(), false)
//        }
//        imageData = bitmapToByteArray(resized!!)
//
//        MyView.rect.clear()
//        MyView.bmp = resized
//        my_view_pdf.invalidate()
//    }
}
