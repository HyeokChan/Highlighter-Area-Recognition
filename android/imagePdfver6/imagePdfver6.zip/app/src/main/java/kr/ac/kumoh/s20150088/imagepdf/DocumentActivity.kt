package kr.ac.kumoh.s20150088.imagepdf

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DocumentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_document)
    }
}
