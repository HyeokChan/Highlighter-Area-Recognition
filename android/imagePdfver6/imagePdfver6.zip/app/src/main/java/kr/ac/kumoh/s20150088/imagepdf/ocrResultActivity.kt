package kr.ac.kumoh.s20150088.imagepdf

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_ocr_result.*

class ocrResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ocr_result)
        var data:String
        data = intent.getStringExtra("ocr")
        ocr_eb.setText(data)
    }
}